// TODO: Implement MovesPanel.jsx
export default function MovesPanel() { return <div>MovesPanel.jsx</div>; }